#1. Count the total number of records in each table of the database
use imdb;
select 'director_mapping' as table_name,count(*) as total_records from director_mapping
union all
select 'genre' as table_name,count(*) as total_records from genre
union all
select 'movie' as table_name,count(*) as total_records from movie
union all
select 'ratings' as table_name,count(*) as total_records from ratings
union all
select 'role_mapping' as table_name,count(*) as total_records from role_mapping;

#2. Identify which columns in the movie table contain null values.
select 'id' as table_name,count(*) from movie where id is null union
select 'title' as table_name,count(*) from movie where title  union
select 'year' as table_name,count(*) from movie where year is null union
select'date_published' as table_name,count(*) from movie where date_published is null union
select 'duration' as table_name,count(*) from movie where duration is null  union
select'country'  as table_name,count(*)from movie where country is null  union
select'worlwide_gross_income' as table_name,count(*) from movie where worlwide_gross_income is null  union
select'languages' as table_name,count(*)from movie where languages is null union
select'production_company' as table_name,count(*) from movie where production_company is null ;

#3. Determine the total number of movies released each year, and analyze how the trend changes month-wise
select year,count(id) as no_of_movies from movie
 group by year
 order by year;
 
 select year,month(date_published) as months,monthname(date_published) as month_name,count(id) as no_of_movies from movie
 group by year,months,month_name
 order by year,no_of_movies desc;

#4. How many movies were produced in either the USA or India in the year 2019?
select country,count(country) as no_of_movies from movie 
where (country = 'usa' or country= 'india')
group by country;

#5. List the unique genres in the dataset, and count how many movies belong exclusively to one genre.
select distinct genre,count(distinct movie_id) as no_of_movies from genre group by genre;
#5. List the unique genres in the dataset, and count how many movies belong exclusively to one genre.
select genre,count(distinct movie_id) as no_of_movies
from genre
where movie_id in(select movie_id from genre group by movie_id having count(genre=1)) group by genre
order by no_of_movies desc;

#6. Which genre has the highest total number of movies produced?
select genre,count(*) as total_no from genre
group by genre
order by count(*) desc;

#7. Calculate the average movie duration for each genre.
select genre.genre,avg(movie.duration) 
from movie inner join genre on movie.id=genre.movie_id
group by genre;

#8. Identify actors or actresses who have appeared in more than three movies with an average rating below 5.
SELECT n.name,COUNT(rm.movie_id) AS movie_count
FROM role_mapping rm
JOIN ratings r 
ON rm.movie_id = r.movie_id
join names n on rm.name_id=n.id
WHERE r.avg_rating < 5 and (rm.category='actor' or rm.category='actress')
GROUP BY n.name
HAVING COUNT(rm.movie_id) > 3
order by movie_count desc;


#9. Find the minimum and maximum values for each column in the ratings table, excluding the movie_id column.
select 
max(avg_rating) as max_avg_rating,min(avg_rating) as min_avg_rating,
max(total_votes) as max_total_votes,min(total_votes) as min_of_total_votes,
max(median_rating) as max_median_rating,min(median_rating) as min_of_median_rating 
from ratings;

#10. Which are the top 10 movies based on their average rating?
select m.title,r.avg_rating
from movie m join ratings r on m.id=r.movie_id
group by r.avg_rating,m.title
order by r.avg_rating desc
limit 11;

#11. Summarize the ratings table by grouping movies based on their median ratings.
select m.title,r.median_rating from movie m join ratings r on
m.id=r.movie_id
order by r.median_rating desc;

#11. Summarize the ratings table by grouping movies based on their median ratings.
select r.median_rating,count(r.movie_id) as no_of_movies from ratings r
group by r.median_rating
order by r.median_rating desc;

#12. How many movies, released in March 2017 in the USA within a specific genre, had more than 1,000 votes?
select distinct g.genre,count(r.movie_id)
from genre g join movie m on g.movie_id=m.id
join ratings r on g.movie_id=r.movie_id
where m.country='usa' and r.total_votes>1000 and m.date_published between '2017-03-01' and '2017-03-31'
group by g.genre
order by g.genre;

#13. Find movies from each genre that begin with the word “The” and have an average rating greater than 8.
select g.genre,m.title from genre g join movie m on 
g.movie_id=m.id join ratings r on g.movie_id=r.movie_id
where m.title like 'the%' and r.avg_rating>8
;
select g.genre,m.title from genre g join movie m on 
g.movie_id=m.id join ratings r on g.movie_id=r.movie_id
where m.title like 'the%' and r.avg_rating>8;

#14. Of the movies released between April 1, 2018, and April 1, 2019, how many received a median rating of 8?
select m.date_published,count(r.movie_id) as no_of_movies from ratings r join movie m on
r.movie_id=m.id
where r.median_rating=8 and m.date_published between '2018-04-01' and '2019-04-01'
group by m.date_published
order by m.date_published;
#14.
select count(r.movie_id) as no_of_movies from ratings r join movie m on
r.movie_id=m.id
where r.median_rating=8 and m.date_published between '2018-04-01' and '2019-04-01'
;

#15. Do German movies receive more votes on average than Italian movies?
select m.country,avg(r.total_votes) as avg_votes from movie m join ratings r on m.id=r.movie_id
where m.country like 'Germany' or m.country like'Italy'
group by m.country;
#15(using in)
select m.country,avg(r.total_votes) as avg_votes from movie m join ratings r on m.id=r.movie_id
where m.country in ('Germany','Italy')
group by m.country;

#16. Identify the columns in the names table that contain null values.
select 'id' as id,count(*) as nullcount from names where id is null 
union all
select 'name' as name,count(*) as nullcount from names where name is null
union all
select 'height' as height,count(*) as height from names where height is null
union all
select 'date_of_birth' as date_of_birth,count(*) as date_of_birth from names where date_of_birth is null
union all
select 'known_for_movies' as known_for_movies,count(*) as known_for_movies from names where known_for_movies is null
;

#17. Who are the top two actors whose movies have a median rating of 8 or higher?
select n.name,max(r.median_rating) as median_rating,count(r.movie_id) as no_of_movies from names n 
inner join role_mapping rm on n.id=rm.name_id
inner join ratings r on rm.movie_id=r.movie_id
where r.median_rating>=8
group by n.name
order by max(r.median_rating) desc;

#17. Who are the top two actors whose movies have a median rating of 8 or higher?
select n.name,max(r.median_rating) as median_rating,count(r.movie_id) as no_of_movies,rm.category
from names n 
inner join role_mapping rm on n.id=rm.name_id
inner join ratings r on rm.movie_id=r.movie_id
where r.median_rating>=8 and rm.category='actor'
group by n.name
order by median_rating desc,no_of_movies desc ;
select n.name,max(r.median_rating) as median_rating,count(r.movie_id) as no_of_movies,rm.category
from names n 
inner join role_mapping rm on n.id=rm.name_id
inner join ratings r on rm.movie_id=r.movie_id
where r.median_rating>=8 and rm.category='actor' or rm.category='actress'
group by n.name,rm.category
order by no_of_movies desc ;

#18. Which are the top three production companies based on the total number of votes their movies received?- selected most voted movies of each cmpny
select m.production_company,r.total_votes from movie m
join ratings r on m.id=r.movie_id
order by r.total_votes desc
limit 5 ;
#18 - Which are the top three production companies based on the total number of votes their movies received?- summed the toal votes for all their movies
select m.production_company,sum(r.total_votes) as total_votes from movie m
join ratings r on m.id=r.movie_id
group by m.production_company
order by sum(r.total_votes) desc
limit 3 ;

#19. How many directors have worked on more than three movies?
select count(name_id) as no_of_directors from 
(select name_id from director_mapping group by name_id having count(movie_id)>3 ) as subquery;

#20. Calculate the average height of actors and actresses separately.
select distinct rm.category,avg(n.height) as avg_height
from role_mapping rm inner join names n on rm.name_id=n.id
group by rm.category;

#21. List the 10 oldest movies in the dataset along with their title, country, and director.
select m.title,m.country,n.name,m.date_published
from director_mapping dr inner join movie m on dr.movie_id=m.id
inner join names n on dr.name_id=n.id
order by m.date_published
limit 10;

#22. List the top 5 movies with the highest total votes, along with their genres.
select distinct m.title,r.total_votes,g.genre
from movie m inner join ratings r on m.id=r.movie_id
inner join genre g on m.id=g.movie_id
order by r.total_votes desc;

select distinct  m.title
from movie m inner join ratings r on m.id=r.movie_id
inner join genre g on m.id=g.movie_id
group by m.title
order by sum(r.total_votes) desc
limit 10;

#23. Identify the movie with the longest duration, along with its genre and production company
select m.title,m.duration,m.production_company,g.genre
from movie m inner join genre g on m.id=g.movie_id
order by m.duration desc
limit 2;

#24. Determine the total number of votes for each movie released in 2018.
select m.title,r.total_votes from movie m join ratings r
on m.id=r.movie_id
where m.year =2018;

#25. What is the most common language in which movies were produced?
select m.languages,count(m.id) as no_of_movies from movie m
group by m.languages
order by count(m.id) desc
limit 1;
